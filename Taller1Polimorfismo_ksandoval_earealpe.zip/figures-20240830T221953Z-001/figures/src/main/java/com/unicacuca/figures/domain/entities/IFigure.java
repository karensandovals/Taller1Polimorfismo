/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.unicacuca.figures.domain.entities;

/**
 *
 * @author linit
 */
public interface IFigure {
   //La interfaces no tienen variables, sólo funciones.    
    public double calculateArea();
    public double calculatePerimeter();
    
}
